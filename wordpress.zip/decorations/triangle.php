<div class="triangle-area desktop-only">
    <div class="triangle"></div>
</div>