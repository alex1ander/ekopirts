<div class="trapezoid-area desktop-only">
    <div class="trapezoid"></div>
</div>