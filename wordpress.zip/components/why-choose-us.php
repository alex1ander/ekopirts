<section class="why-choose-us">
    <div class="container">
        <div class="why-us-content">
            <div class="info">
                <h2>KĀDĒĻ MĒS?</h2>

                <div class="benefits-list">
                    <?php for($i = 0; $i < 5; $i++):?>
                        <div class="benefit">
                            <div class="checkmark">
                                <div class="checkmark-area">
                                    <svg width="36" height="30">
                                        <use href="#checkmark"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="title">No skices,līdz pirts slotiņai</div>
                            <div class="text">Piedalamies pirts izstrādā no projekta, līdz pilnīgai pirts aprīkošanai, ieskaitot, pirts slotiņas</div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="video">
                <iframe 
                    src="https://www.youtube.com/embed/tgbNymZ7vqY">
                </iframe>
            </div>
        </div>
    </div>
</section>