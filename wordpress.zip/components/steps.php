<aside class="steps">
    <div class="container">
        <div class="steps-flex">
            <div class="step-item first">
                <h3>Produktu pasūtīšanas process</h3>
                <p>Trīs vienkārši soļi, līdz Jūsu sapņu pirts, kubls, dārza māja atradīsies Jūsu īpašumā.</p>
            </div>
            <div class="step-item">
                <svg width="126" height="125">
                    <use href="#lamp"></use>
                </svg>
                <h3>Produktu pasūtīšanas process</h3>
                <p>Izmantojam produktu katalogu, vai pasūtīšanas formu.</p>
            </div>
            <div class="step-item">
                <svg width="126" height="125">
                    <use href="#lamp"></use>
                </svg>
                <h3>Produktu pasūtīšanas process</h3>
                <p>Izmantojam produktu katalogu, vai pasūtīšanas formu..</p>
            </div>
            <div class="step-item">
                <svg width="126" height="125">
                    <use href="#lamp"></use>
                </svg>
                <h3>Produktu pasūtīšanas process</h3>
                <p>Izmantojam produktu katalogu, vai pasūtīšanas formu.</p>
            </div>
        </div>
    </div>
</aside>