<aside class="promotions-section">
    <div class="promotions-side">
        <div class="container">
            <div class="promotions-content">
                <div class="promotions-info">
                    <h4 class="promotions-title">RT TIMBER ir uzņēmums, kas specializējas mucu piršu, kublu, dārza un kempinga māju ražošanā..</h4>
                    <p class="promotions-text">Ātra izgatavošana. Mūsu apskates vietās var iegādāties produktus, kas var tikt uzstādīti jau tajā pašā dienā.</p>
                </div>
                <div class="promotions-btn">
                    <a href="#" class="btn btn-matte">+371 25912321</a>
                    <svg class="leaflet" width="278" height="170" width="182" height="45">
                        <use href="#leaflet"></use>
                    </svg>
                </div>
            </div>
        </div>
    </div>
</aside>